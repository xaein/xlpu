const homeContent = `
<div id="welcome-container">
    <h2>Welcome to xLauncher Plus: Help</h2>
    <p>xLauncher Plus is an advanced Electron-based application launcher with a graphical user interface for managing and launching various applications.</p>
    <h3>Features</h3>
    <ul>
        <li>Launch applications from Steam, Epic Games, Amazon Games, and more.</li>
        <li>Manage your applications with ease.</li>
        <li>Customizable categories.</li>
        <li>Mark and quickly access favorite applications.</li>
        <li>Theme Support with customizable themes.</li>
    </ul>
</div>
`;