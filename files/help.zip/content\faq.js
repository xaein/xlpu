const faqContent = `
<div id="welcome-container">
    <h2>FAQ</h2>
    <p>Frequently Asked Questions:</p>
    <h3>Why was xLauncher Plus created?</h3>
    <p>xLauncher Plus was created to improve upon the xLauncher CLI application.<br>
    That was originally created to help integrate application launching from home devices, like Google Home and Amazon Alexa.</p>
    <h3>What can it do?</h3>
    <p>xLauncher Plus can launch applications from a variety of sources, including Steam, Epic Games, and more.<br>
    It also allows you to manage your applications with ease, and customize the categories.<br>
    If you want full integration with a voice assistant, we currently support <a href="https://www.triggercmd.com/en/" target="_blank">TriggerCMD</a>.<br>
    No you dont need TriggerCMD to use xLauncher Plus, the user interface is for those who want to launch applictions from various sources.</p>
</div>
`;