const featuresMainListContent = `
<div id="welcome-container">
    <h2>Main List</h2>
    <p>The Main List section allows you to manage and launch your applications. Here are some key features:</p>
    <ul>
        <li>View and favourite your applications.</li>
        <li>Search for applications using simple or advanced search options. (Only available on Main List)</li>
        <li>Select and launch applications directly from the list.</li>
    </ul>
    <div class="centered-image">
        <img src="images/02_Main_List_Default.png" alt="Main - Default" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/02_Main_List_Search_Advanced.png" alt="Main - Search Advanced" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/02_Main_List_Search_Simple.png" alt="Main - Search Simple" class="thumbnail" onclick="showFullSizeImage(this.src)"><br>
        <div class="centered-image2">
            <img src="images/02_Main_List_App_Selection.png" alt="App Selection" class="thumbnail" onclick="showFullSizeImage(this.src)">
            <img src="images/02_Main_List_App_Launch.png" alt="App Launch" class="thumbnail" onclick="showFullSizeImage(this.src)">
        </div>
    </div>
    <p>Click on the images above to view them in full size.</p>
    <p>These are examples of what the main list looks like when you have setup your applications.</p>
</div>
`;

const featuresDatabaseControlContent = `
<div id="welcome-container">
    <h2>Database Control</h2>
    <p>The Database Control section allows you to manage your application database. Here are some key features:</p>
    <ul>
        <li>Add, rename, and remove categories to organize your applications.</li>
        <li>Add, edit, and remove applications within each category.</li>
        <li>Save changes and reload the database to apply updates.</li>
    </ul>
    <div class="centered-image">
        <img src="images/03_Database_Control.png" alt="Database Control" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/03_Database_Control_Add_Category.png" alt="Add Category" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/03_Database_Control_Rename_Category.png" alt="Rename Category" class="thumbnail" onclick="showFullSizeImage(this.src)"><br>
        <img src="images/03_Database_Control_Remove_Category.png" alt="Remove Category" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/03_Database_Control_Add_Appliction.png" alt="Add Application" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/03_Database_Control_Edit_Application.png" alt="Edit Application" class="thumbnail" onclick="showFullSizeImage(this.src)"><br>
        <div class="centered-image2">
            <img src="images/03_Database_Control_Remove_Application.png" alt="Remove Application" class="thumbnail" onclick="showFullSizeImage(this.src)">
            <img src="images/03_Database_Control_Saving_Reloading.png" alt="Saving & Reloading" class="thumbnail" onclick="showFullSizeImage(this.src)">
        </div>
    </div>
    <p>Click on the images above to view them in full size.</p>
    <p>These images demonstrate the various functionalities available in the Database Control section.</p>
    <p>These images are examples of what the Database Control section looks like when you have added your applications.</p>
</div>
`;

const featuresThemesContent = `
<div id="welcome-container">
    <h2>Themes</h2>
    <p>The Themes section allows you to customize the appearance of xLauncher Plus. Here are some key features:</p>
    <ul>
        <li>Select from a variety of pre-defined themes.</li>
        <li>Preview themes before applying them.</li>
        <li>Import and remove custom themes.</li>
        <li>Access <a href="https://github.com/xaein/xlauncherplus/tree/main/additional_themes#readme" target="_blank">additional themes</a> created by the community.</li>
    </ul>
    <div class="centered-image">
        <img src="images/04_Themes.png" alt="Themes" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/04_Themes_Application.png" alt="Theme Application" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/04_Themes_Dark.png" alt="Dark Theme" class="thumbnail" onclick="showFullSizeImage(this.src)">
    </div>
    <p>Click on the images above to view them in full size.</p>
    <p>These images demonstrate the various functionalities available in the Themes section.</p>
    <p>These images are examples of what the Themes section looks like when you have applied different themes.</p>
</div>
`;

const featuresConfigurationContent = `
<div id="welcome-container">
    <h2>Configuration</h2>
    <p>The Configuration section allows you to customize various settings of xLauncher Plus. Here are some key features:</p>
    <ul>
        <li>General settings for application behavior.</li>
        <li>
        TriggerCMD integration for use with Amazon Alex.<br>
        TriggerCMD is not included with xLauncher Plus.<br>
        This section only shows up if TriggerCMD is installed.
        </li>
        <li>Updater to keep the application up to date.</li>
    </ul>
    <div class="centered-image">
        <img src="images/05_Configuration_General.png" alt="Configuration - General" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/05_Configuration_TriggerCMD_Integration.png" alt="Configuration - TriggerCMD Integration" class="thumbnail" onclick="showFullSizeImage(this.src)">
        <img src="images/05_Configuration_Updater.png" alt="Configuration - Updater" class="thumbnail" onclick="showFullSizeImage(this.src)">
    </div>
    <p>Click on the images above to view them in full size.</p>
    <p>These images demonstrate the various functionalities available in the Configuration section.</p>
    <p>These images are examples of what the Configuration section looks like when you have customized your settings.</p>
</div>
`;

const featuresLoggingContent = `
<div id="welcome-container">
    <h2>Logging</h2>
    <p>The Logging section provides detailed logs of application activities. Here are some key features:</p>
    <ul>
        <li>View real-time logs of application launches.</li>
        <li>Shows if an application is not found.</li>
        <li>Uses settings from the Configuration section, and colours from the applied theme.</li>
    </ul>
    <div class="centered-image">
        <img src="images/06_Logging.png" alt="Logging" class="thumbnail" onclick="showFullSizeImage(this.src)">
    </div>
    <p>Click on the image above to view it in full size.</p>
    <p>This image demonstrates the logging functionalities available in the Logging section.</p>
    <p>This image is an example of what the Logging section looks like when you have logged various activities.</p>
</div>
`;