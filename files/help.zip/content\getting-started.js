const gettingStartedContent = `
<div id="welcome-container">
    <h2>Getting Started</h2>
    <p>To get started with xLauncher Plus, follow these steps:</p>
    <ol>
        <li>
            <div>
                Launch the application. You will first see the welcome screen.
                <br>Then when you click the "Start Adding Applications" button, you will be taken to the database control screen.
                <br>These screens are shown in the images below:
                <div class="centered-image">
                    <img src="images/01_Welcome.png" alt="Welcome Screen" class="thumbnail" onclick="showFullSizeImage(this.src)">
                    <img src="images/03_Database_Control.png" alt="Database Control" class="thumbnail" onclick="showFullSizeImage(this.src)">
                </div><br>
                They are only an example of what the screens look like. Yours will be different.
            </div>
        </li>
    </ol>
    <ol start="2">
        <li>Navigate through the tabs at the top to access different sections such as Database Control, Themes, Configuration, and Logging.</li>
        <li>Use the Launch List to manage and launch your applications. You can add, remove, and organize applications as needed.</li>
        <li>Click on the "Launch" button to start the selected application.</li>
        <li>Use the "Exit" button to close the application.</li>
    </ol>
</div>
`;