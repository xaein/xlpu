const content = {
    'home': homeContent,
    'getting-started': gettingStartedContent,
    'features-main-list': featuresMainListContent,
    'features-database-control': featuresDatabaseControlContent,
    'features-themes': featuresThemesContent,
    'features-configuration': featuresConfigurationContent,
    'features-logging': featuresLoggingContent,
};

function loadContent(page) {
    document.getElementById('content').innerHTML = content[page] || '<p>Content not found.</p>';
}

function showFullSizeImage(src) {
    const modal = document.getElementById('full-size-image-container');
    const fullSizeImage = document.getElementById('full-size-image');
    fullSizeImage.src = src;
    fullSizeImage.classList.remove('zoom-out');
    modal.style.display = 'block';
}

function hideFullSizeImage() {
    const modal = document.getElementById('full-size-image-container');
    const fullSizeImage = document.getElementById('full-size-image');
    fullSizeImage.classList.add('zoom-out');
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300); // Match the duration of the zoom-out animation
}

// Load the default content
document.addEventListener('DOMContentLoaded', () => {
    loadContent('home');
});